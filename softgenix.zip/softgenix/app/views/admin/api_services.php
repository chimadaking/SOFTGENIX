<?php require BASE_PATH . '/app/views/layouts/header.php'; ?>

<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Manage API Services</h1>
        <a href="<?php echo site_url('api'); ?>" class="btn btn-secondary">
            ← Back to API Instances
        </a>
    </div>

    <?php flash('success'); ?>
    <?php flash('error', '', 'alert alert-danger'); ?>

    <?php if (!empty($data['services'])): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Service</th>
                        <th>Category</th>
                        <th>API Rate</th>
                        <th>Markup</th>
                        <th>Final Price</th>
                        <th>Status</th>
                        <th>Visible</th>
                        <th>Extras</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($data['services'] as $s): ?>
                    <tr>
                        <td><?php echo $s->id; ?></td>
                        <td>
                            <strong><?php echo h($s->name); ?></strong><br>
                            <small class="text-muted">
                                <?php echo h($s->instance_name ?? ''); ?>
                            </small>
                        </td>
                        <td><?php echo h($s->category); ?></td>
                        <td>$<?php echo number_format($s->api_rate, 4); ?></td>

                        <form method="post" action="<?php echo site_url('api/updateService'); ?>">
                            <input type="hidden" name="id" value="<?php echo $s->id; ?>">

                            <td>
                                <input type="number" step="0.01" name="markup"
                                       value="<?php echo $s->markup; ?>"
                                       class="form-control form-control-sm">
                            </td>

                            <td>
                                <strong>$<?php echo number_format($s->final_price, 4); ?></strong>
                            </td>

                            <td>
                                <select name="status" class="form-select form-select-sm">
                                    <option value="inactive" <?php if ($s->status==='inactive') echo 'selected'; ?>>Inactive</option>
                                    <option value="active" <?php if ($s->status==='active') echo 'selected'; ?>>Active</option>
                                </select>
                            </td>

                            <td>
                                <select name="visible" class="form-select form-select-sm">
                                    <option value="no" <?php if ($s->visible==='no') echo 'selected'; ?>>No</option>
                                    <option value="yes" <?php if ($s->visible==='yes') echo 'selected'; ?>>Yes</option>
                                </select>
                            </td>

                            <td>
                                <?php if (!empty($s->extra)): ?>
                                    <details>
                                        <summary>View</summary>
                                        <pre class="small bg-light p-2"><?php echo h(json_encode(json_decode($s->extra), JSON_PRETTY_PRINT)); ?></pre>
                                    </details>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>

                            <td>
                                <button class="btn btn-sm btn-success">
                                    Save
                                </button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            No services found. Sync an API instance first.
        </div>
    <?php endif; ?>

</div>

<?php require BASE_PATH . '/app/views/layouts/footer.php'; ?>
