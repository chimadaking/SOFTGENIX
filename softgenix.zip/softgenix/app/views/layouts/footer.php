            </div> <!-- col-md-9 or container -->
        </div> <!-- row -->
    </div> <!-- container -->

    <footer class="footer mt-auto py-3 bg-white border-top shadow-sm mt-5">
        <div class="container text-center">
            <span class="text-muted">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</span>
        </div>
    </footer>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo BASE_DIR; ?>/js/script.js"></script>
</body>
</html>
