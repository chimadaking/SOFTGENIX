<?php
namespace App\Models;

class Provider extends BaseModel {
    
    public function getAllProviders() {
        return $this->fetchAll("SELECT * FROM providers ORDER BY name ASC");
    }

    public function getActiveProviders() {
        return $this->fetchAll("SELECT * FROM providers WHERE status = 'active' ORDER BY name ASC");
    }

    public function getProviderById($id) {
        return $this->fetch("SELECT * FROM providers WHERE id = ?", [$id]);
    }

    public function getProviderBySlug($slug) {
        return $this->fetch("SELECT * FROM providers WHERE slug = ?", [$slug]);
    }

    public function createProvider($data) {
        $slug = $this->generateSlug($data['name']);
        $sql = "INSERT INTO providers (name, slug, description, base_url_template, documentation_url, status) 
                VALUES (?, ?, ?, ?, ?, ?)";
        return $this->query($sql, [
            $data['name'],
            $slug,
            $data['description'] ?? null,
            $data['base_url_template'] ?? null,
            $data['documentation_url'] ?? null,
            $data['status'] ?? 'active'
        ]);
    }

    public function updateProvider($id, $data) {
        $sql = "UPDATE providers 
                SET name = ?, description = ?, base_url_template = ?, documentation_url = ?, status = ?, updated_at = NOW()
                WHERE id = ?";
        return $this->query($sql, [
            $data['name'],
            $data['description'] ?? null,
            $data['base_url_template'] ?? null,
            $data['documentation_url'] ?? null,
            $data['status'] ?? 'active',
            $id
        ]);
    }

    public function deleteProvider($id) {
        $sql = "DELETE FROM providers WHERE id = ?";
        return $this->query($sql, [$id]);
    }

    private function generateSlug($name) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
        return $slug;
    }
}